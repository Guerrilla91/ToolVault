
function applyBlackWhitePrintStyle(){
  let style=document.getElementById('toolvault-bw-print');
  if(style) return;
  style=document.createElement('style');
  style.id='toolvault-bw-print';
  style.textContent=`
    @media print{
      *{
        color:#000 !important;
        border-color:#000 !important;
        box-shadow:none !important;
        text-shadow:none !important;
      }
      html,body,.container,.stat,.card,.empty,.detail-item{
        background:#fff !important;
      }
      .badge,.status-Active,.status-Lost,.status-Stolen,.status-Sold,.status-Broken{
        background:#fff !important;
        color:#000 !important;
        border:1px solid #000 !important;
      }
      img{
        -webkit-print-color-adjust:exact !important;
        print-color-adjust:exact !important;
        filter:none !important;
      }
      a{color:#000 !important;text-decoration:none !important}
    }
  `;
  document.head.appendChild(style);
}

const DB_NAME='ToolVaultDB', STORE='tools', DB_VERSION=1;
let db, editingTool=null, pendingToolPhotos=[], pendingReceiptPhotos=[];

const $=id=>document.getElementById(id);
const money=v=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number(v||0));
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));

function openDB(){
  return new Promise((resolve,reject)=>{
    const req=indexedDB.open(DB_NAME,DB_VERSION);
    req.onupgradeneeded=e=>{ const d=e.target.result; if(!d.objectStoreNames.contains(STORE)) d.createObjectStore(STORE,{keyPath:'id'}); };
    req.onsuccess=e=>resolve(e.target.result); req.onerror=e=>reject(e.target.error);
  });
}
function tx(mode='readonly'){return db.transaction(STORE,mode).objectStore(STORE)}
function getAll(){return new Promise((res,rej)=>{const r=tx().getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
function putTool(t){return new Promise((res,rej)=>{const r=tx('readwrite').put(t);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function deleteTool(id){return new Promise((res,rej)=>{const r=tx('readwrite').delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function clearTools(){return new Promise((res,rej)=>{const r=tx('readwrite').clear();r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}

async function fileToDataURL(file,max=1600,quality=.82){
  const data=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)});
  return new Promise(resolve=>{
    const img=new Image(); img.onload=()=>{
      let {width,height}=img; const scale=Math.min(1,max/Math.max(width,height)); width=Math.round(width*scale);height=Math.round(height*scale);
      const c=document.createElement('canvas');c.width=width;c.height=height;c.getContext('2d').drawImage(img,0,0,width,height);
      resolve(c.toDataURL('image/jpeg',quality));
    };img.src=data;
  });
}
async function filesToData(files){const out=[];for(const f of files) out.push(await fileToDataURL(f));return out}

function renderPreviews(){
  const draw=(el,arr,type)=>{el.innerHTML=arr.map((src,i)=>`<div class="preview-item"><img src="${src}"><button type="button" data-type="${type}" data-index="${i}">×</button></div>`).join('')};
  draw($('toolPhotoPreview'),pendingToolPhotos,'tool'); draw($('receiptPhotoPreview'),pendingReceiptPhotos,'receipt');
}
document.addEventListener('click',e=>{
  if(e.target.matches('.preview-item button')){const i=+e.target.dataset.index;(e.target.dataset.type==='tool'?pendingToolPhotos:pendingReceiptPhotos).splice(i,1);renderPreviews()}
});

async function render(){
  const all=await getAll();
  const q=$('searchInput').value.toLowerCase().trim(), cat=$('categoryFilter').value, stat=$('statusFilter').value;
  const filtered=all.filter(t=>{
    const hay=[t.name,t.brand,t.category,t.model,t.serial,t.store,t.location,t.notes].join(' ').toLowerCase();
    return (!q||hay.includes(q))&&(!cat||t.category===cat)&&(!stat||t.status===stat);
  }).sort((a,b)=>(b.updatedAt||'').localeCompare(a.updatedAt||''));

  $('toolCount').textContent=all.length;
  $('purchaseTotal').textContent=money(all.reduce((s,t)=>s+Number(t.purchasePrice||0),0));
  $('replacementTotal').textContent=money(all.reduce((s,t)=>s+Number(t.replacementValue||0),0));

  const cats=[...new Set(all.map(t=>t.category).filter(Boolean))].sort(); const prev=$('categoryFilter').value;
  $('categoryFilter').innerHTML='<option value="">All categories</option>'+cats.map(c=>`<option ${c===prev?'selected':''}>${esc(c)}</option>`).join('');

  $('emptyState').style.display=all.length?'none':'block';
  $('toolGrid').innerHTML=filtered.map(t=>`
    <article class="card">
      <div class="thumb">${t.toolPhotos?.[0]?`<img src="${t.toolPhotos[0]}" alt="">`:'No photo'}</div>
      <div class="card-body">
        <h3>${esc(t.name)}</h3>
        <div class="muted">${esc([t.brand,t.model].filter(Boolean).join(' • '))}</div>
        <div class="row"><span class="badge status-${esc(t.status)}">${esc(t.status||'Active')}</span><strong>${money(t.replacementValue||t.purchasePrice)}</strong></div>
        ${t.serial?`<div class="muted" style="margin-top:8px">Serial: ${esc(t.serial)}</div>`:''}
        <div class="card-actions">
          <button onclick="showDetail('${t.id}')">View</button>
          <button onclick="editTool('${t.id}')">Edit</button>
          <button class="danger" onclick="removeTool('${t.id}')">Delete</button>
        </div>
      </div>
    </article>`).join('');
}

function resetForm(){
  $('toolForm').reset();$('toolId').value='';editingTool=null;pendingToolPhotos=[];pendingReceiptPhotos=[];renderPreviews();$('formTitle').textContent='Add Tool';$('status').value='Active';
}
function openAdd(){resetForm();$('toolDialog').showModal()}
async function editTool(id){
  const all=await getAll(),t=all.find(x=>x.id===id);if(!t)return;editingTool=t;
  for(const key of ['name','brand','category','model','serial','purchasePrice','replacementValue','purchaseDate','store','location','status','notes']) $(key).value=t[key]??'';
  $('toolId').value=t.id;pendingToolPhotos=[...(t.toolPhotos||[])];pendingReceiptPhotos=[...(t.receiptPhotos||[])];renderPreviews();$('formTitle').textContent='Edit Tool';$('toolDialog').showModal()
}
async function removeTool(id){if(confirm('Delete this tool from ToolVault?')){await deleteTool(id);render()}}
async function showDetail(id){
  const t=(await getAll()).find(x=>x.id===id);if(!t)return;
  const field=(label,val)=>val?`<div class="detail-item"><small>${label}</small><strong>${esc(val)}</strong></div>`:'';
  $('detailContent').innerHTML=`
    <div class="detail-head"><div><h2>${esc(t.name)}</h2><div class="muted">${esc(t.brand||'')} ${esc(t.model||'')}</div></div><button onclick="$('detailDialog').close()">✕</button></div>
    <div class="detail-list">
      ${field('Category',t.category)}${field('Status',t.status)}${field('Serial number',t.serial)}
      ${field('Purchase price',money(t.purchasePrice))}${field('Replacement value',money(t.replacementValue))}
      ${field('Purchase date',t.purchaseDate)}${field('Purchased from',t.store)}${field('Storage location',t.location)}
    </div>
    ${t.notes?`<h3 class="section-title">Notes</h3><p>${esc(t.notes)}</p>`:''}
    ${t.toolPhotos?.length?`<h3 class="section-title">Tool Photos</h3><div class="gallery">${t.toolPhotos.map(x=>`<img src="${x}">`).join('')}</div>`:''}
    ${t.receiptPhotos?.length?`<h3 class="section-title">Receipt Photos</h3><div class="gallery">${t.receiptPhotos.map(x=>`<img src="${x}">`).join('')}</div>`:''}`;
  $('detailDialog').showModal()
}

$('toolForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const now=new Date().toISOString();
  const t={
    id:$('toolId').value||crypto.randomUUID(),
    name:$('name').value.trim(),brand:$('brand').value.trim(),category:$('category').value.trim(),
    model:$('model').value.trim(),serial:$('serial').value.trim(),purchasePrice:Number($('purchasePrice').value||0),
    replacementValue:Number($('replacementValue').value||0),purchaseDate:$('purchaseDate').value,
    store:$('store').value.trim(),location:$('location').value.trim(),status:$('status').value,notes:$('notes').value.trim(),
    toolPhotos:pendingToolPhotos,receiptPhotos:pendingReceiptPhotos,createdAt:editingTool?.createdAt||now,updatedAt:now
  };
  await putTool(t);$('toolDialog').close();resetForm();render()
});
$('toolPhotos').addEventListener('change',async e=>{pendingToolPhotos.push(...await filesToData([...e.target.files]));e.target.value='';renderPreviews()});
$('receiptPhotos').addEventListener('change',async e=>{pendingReceiptPhotos.push(...await filesToData([...e.target.files]));e.target.value='';renderPreviews()});

$('addBtn').onclick=openAdd;$('emptyAddBtn').onclick=openAdd;$('closeDialog').onclick=()=>$('toolDialog').close();$('cancelBtn').onclick=()=>$('toolDialog').close();
['searchInput','categoryFilter','statusFilter'].forEach(id=>$(id).addEventListener(id==='searchInput'?'input':'change',render));
$('pdfBtn').onclick=()=>$('reportDialog').showModal();
$('closeReportDialog').onclick=()=>$('reportDialog').close();
$('cancelReportBtn').onclick=()=>$('reportDialog').close();

function reportEscape(s){return String(s??'').replace(/[&<>\"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#039;'}[m]))}
function reportMoney(v){return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number(v||0))}
function buildReportHTML(tools,opts){
  const totalPurchase=tools.reduce((s,t)=>s+Number(t.purchasePrice||0),0);
  const totalReplacement=tools.reduce((s,t)=>s+Number(t.replacementValue||0),0);
  const generated=new Date().toLocaleString();
  const rows=tools.map((t,i)=>`
    <section class="tool">
      <div class="tool-head"><div><div class="num">ITEM ${i+1}</div><h2>${reportEscape(t.name)}</h2><p>${reportEscape([t.brand,t.category].filter(Boolean).join(' • '))}</p></div><div class="value">${reportMoney(t.replacementValue||t.purchasePrice)}</div></div>
      <div class="details">
        <div><span>Model</span><b>${reportEscape(t.model||'—')}</b></div>
        <div><span>Serial</span><b>${reportEscape(t.serial||'—')}</b></div>
        <div><span>Purchase Price</span><b>${reportMoney(t.purchasePrice)}</b></div>
        <div><span>Replacement Value</span><b>${reportMoney(t.replacementValue)}</b></div>
        <div><span>Purchase Date</span><b>${reportEscape(t.purchaseDate||'—')}</b></div>
        <div><span>Purchased From</span><b>${reportEscape(t.store||'—')}</b></div>
        <div><span>Storage Location</span><b>${reportEscape(t.location||'—')}</b></div>
        <div><span>Status</span><b>${reportEscape(t.status||'Active')}</b></div>
      </div>
      ${t.notes?`<div class="notes"><span>Notes</span><p>${reportEscape(t.notes)}</p></div>`:''}
      ${t.toolPhotos?.length?`<div class="photos">${t.toolPhotos.map((x,j)=>`<figure><img src="${x}"><figcaption>Tool photo ${j+1}</figcaption></figure>`).join('')}</div>`:'<p class="no-photo">No tool photo recorded.</p>'}
    </section>`).join('');
  const receiptPages=opts.includeReceipts?tools.filter(t=>t.receiptPhotos?.length).map((t,i)=>`
    <section class="receipt-page page-break">
      <h2>Receipt Evidence - ${reportEscape(t.name)}</h2>
      <p class="sub">Model: ${reportEscape(t.model||'—')} &nbsp; Serial: ${reportEscape(t.serial||'—')}</p>
      <div class="receipt-grid">${t.receiptPhotos.map((x,j)=>`<figure><img src="${x}"><figcaption>Receipt ${j+1}</figcaption></figure>`).join('')}</div>
    </section>`).join(''):'';
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${reportEscape(opts.title)}</title><style>
    @page{size:letter;margin:.48in}*{box-sizing:border-box}body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;color:#111;margin:0;background:white;font-size:10.5pt}.cover{border-bottom:4px solid #111827;padding-bottom:18px;margin-bottom:18px}.brand{font-size:12pt;font-weight:900;letter-spacing:.08em;color:#b91c1c}.cover h1{font-size:26pt;margin:5px 0 8px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:16px}.meta div,.summary div{border:1px solid #d1d5db;padding:9px;border-radius:6px}.meta span,.details span,.notes span{display:block;color:#666;font-size:8.5pt;text-transform:uppercase;letter-spacing:.04em}.summary{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:14px 0 20px}.summary b{display:block;font-size:15pt;margin-top:3px}.tool{border:1px solid #d1d5db;border-radius:8px;padding:12px;margin:0 0 14px;break-inside:avoid;page-break-inside:avoid}.tool-head{display:flex;justify-content:space-between;gap:15px;border-bottom:1px solid #e5e7eb;padding-bottom:8px}.tool-head h2{font-size:15pt;margin:2px 0}.tool-head p,.sub{color:#555;margin:0}.num{font-size:7.5pt;color:#777;font-weight:800;letter-spacing:.08em}.value{font-size:15pt;font-weight:900;white-space:nowrap}.details{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-top:9px}.details div{background:#f3f4f6;border-radius:5px;padding:7px;min-height:45px}.details b{display:block;margin-top:2px;overflow-wrap:anywhere}.notes{margin-top:9px;border-left:3px solid #9ca3af;padding-left:8px}.notes p{margin:3px 0}.photos{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:10px}.photos figure,.receipt-grid figure{margin:0}.photos img{width:100%;height:145px;object-fit:contain;border:1px solid #ddd;border-radius:5px}.photos figcaption,.receipt-grid figcaption{text-align:center;color:#666;font-size:7.5pt;margin-top:2px}.no-photo{color:#777;font-style:italic}.signature{display:grid;grid-template-columns:1fr 1fr;gap:28px;margin-top:36px;break-inside:avoid}.sigline{border-top:1px solid #111;padding-top:5px;margin-top:38px}.page-break{break-before:page;page-break-before:always}.receipt-page h2{margin-top:0}.receipt-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.receipt-grid img{width:100%;max-height:8.4in;object-fit:contain;border:1px solid #ddd}.footer-note{margin-top:18px;color:#666;font-size:8pt}.screen-only{padding:12px;background:#fff3cd;border:1px solid #ffe69c;margin-bottom:14px;border-radius:6px}@media print{.screen-only{display:none}.tool{box-shadow:none}}@media(max-width:700px){.details{grid-template-columns:1fr 1fr}.photos,.receipt-grid{grid-template-columns:1fr}.meta,.summary{grid-template-columns:1fr}}
  </style></head><body>
    <div class="screen-only"><b>Ready to create your PDF.</b> Use Print, then save/share the PDF from your device.</div>
    <section class="cover"><div class="brand">TOOLVAULT</div><h1>${reportEscape(opts.title)}</h1><p>Personal tool ownership and inventory record</p>
      <div class="meta"><div><span>Owner</span><b>${reportEscape(opts.owner||'—')}</b></div><div><span>Company / Employer</span><b>${reportEscape(opts.company||'—')}</b></div><div><span>Date Generated</span><b>${reportEscape(generated)}</b></div><div><span>Report Status</span><b>Personal Property Inventory</b></div></div>
    </section>
    <section class="summary"><div><span>Total Tools</span><b>${tools.length}</b></div><div><span>Total Purchase Value</span><b>${reportMoney(totalPurchase)}</b></div><div><span>Total Replacement Value</span><b>${reportMoney(totalReplacement)}</b></div></section>
    ${rows||'<p>No tools recorded.</p>'}
    <section class="signature"><div><div class="sigline">Tool Owner Signature / Date</div></div><div><div class="sigline">Company Representative / Date</div></div></section>
    <p class="footer-note">This report is an inventory record prepared by the tool owner. Acceptance, valuation, reimbursement, and proof-of-ownership requirements are determined by the receiving company or insurer.</p>
    ${receiptPages}
    <script>window.addEventListener('load',()=>{setTimeout(()=>window.print(),600)});<\/script>
  </body></html>`;
}

$('reportForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const tools=(await getAll()).sort((a,b)=>(a.category||'').localeCompare(b.category||'')||(a.name||'').localeCompare(b.name||''));
  const opts={owner:$('reportOwner').value.trim(),company:$('reportCompany').value.trim(),title:$('reportTitle').value.trim()||'Personal Tool Inventory',includeReceipts:$('includeReceipts').checked};
  const w=window.open('','_blank');
  if(!w){alert('Please allow pop-ups for ToolVault so the PDF report can open.');return}
  w.document.open();w.document.write(buildReportHTML(tools,opts));w.document.close();
  $('reportDialog').close();
});

$('csvBtn').onclick=async()=>{
  const all=await getAll(), cols=['name','brand','category','model','serial','purchasePrice','replacementValue','purchaseDate','store','location','status','notes'];
  const cell=v=>`"${String(v??'').replaceAll('"','""')}"`;
  const csv=[cols.join(','),...all.map(t=>cols.map(c=>cell(t[c])).join(','))].join('\n');
  downloadBlob(new Blob([csv],{type:'text/csv'}),'toolvault-inventory.csv');
};
$('backupBtn').onclick=async()=>{
  const all=await getAll();downloadBlob(new Blob([JSON.stringify({version:1,exportedAt:new Date().toISOString(),tools:all},null,2)],{type:'application/json'}),'toolvault-backup.json');
};
$('restoreInput').onchange=async e=>{
  try{
    const data=JSON.parse(await e.target.files[0].text());if(!Array.isArray(data.tools))throw Error();
    if(!confirm(`Restore ${data.tools.length} tools? This will replace the current inventory.`))return;
    await clearTools();for(const t of data.tools)await putTool(t);await render();alert('Backup restored.');
  }catch{alert('That backup file could not be restored.')}finally{e.target.value=''}
};
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}

window.editTool=editTool;window.removeTool=removeTool;window.showDetail=showDetail;window.$=$;

(async()=>{db=await openDB();await render();if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{})})();
