# ToolVault v2

A free, offline-first personal tool inventory app designed for insurance documentation.

## Features
- Add/edit/delete tools
- Tool, serial plate, and receipt photos
- Model and serial numbers
- Purchase and replacement values
- Storage location and status
- Search and filters
- Dedicated Create PDF workflow with owner/company fields, totals, tool photos, serial/model numbers, values, signature lines, and optional receipt evidence pages
- CSV export
- Full JSON backup/restore including photos
- Installable on iPhone as a Home Screen web app
- Works offline after first load

## Put it on GitHub Pages
1. Create a new GitHub repository named `toolvault`.
2. Upload all files from this folder to the repository root.
3. In GitHub: Settings → Pages.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Choose `main` and `/ (root)`, then Save.
6. Open the GitHub Pages address in Safari on your iPhone.
7. Tap Share → **Add to Home Screen**.

## Important backup note
ToolVault stores data in your browser's IndexedDB on that device. For insurance records, use **Backup JSON** regularly and keep that exported file in a separate safe/cloud location. Clearing Safari website data can erase local records.

## Insurance note
This app organizes documentation; it does not guarantee an insurer will accept a particular valuation or proof-of-ownership format.

## Create and email a PDF
Open ToolVault → **Create PDF** → enter your name/company → optionally include receipts → **Build PDF Report**. The report opens and launches the device print/share flow. On iPhone, use the print preview/share controls to save the report to Files or attach/share it as a PDF.
